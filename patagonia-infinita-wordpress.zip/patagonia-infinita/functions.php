<?php
/**
 * Patagonia Infinita · functions.php
 * ------------------------------------------------------------
 * Configuración del tema: estilos, tipografías, ícono de la
 * página (favicon) y pequeñas limpiezas.
 */

// Seguridad: evita que el archivo se abra directamente desde el navegador.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Título de la pestaña del navegador y de Google.
 * Cambialo acá si querés otro texto.
 */
function pi_document_title() {
	return 'Patagonia Infinita · Kayak & Adventure';
}
add_filter( 'pre_get_document_title', 'pi_document_title' );

/**
 * Descripción corta (la que muestran Google y las redes al compartir el link).
 */
function pi_meta_description() {
	return 'Kayak and adventure in Villa La Angostura, Patagonia. Find all the ways to reach Patagonia Infinita.';
}

/**
 * Carga el CSS del tema (style.css).
 * El número de versión evita que el navegador use una copia vieja del CSS.
 */
function pi_enqueue_styles() {
	wp_enqueue_style( 'pi-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );

	// Esta página no usa el editor de bloques: se quitan sus estilos para que cargue más rápido.
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'global-styles' );
}
add_action( 'wp_enqueue_scripts', 'pi_enqueue_styles', 20 );

/**
 * Ícono de la página (favicon) = el SVG de Patagonia Infinita.
 * Archivo: assets/favicon.svg
 * Se usa en: el sitio, el panel de administración y la pantalla de login.
 */
function pi_favicon_tags() {
	$icon = esc_url( get_template_directory_uri() . '/assets/favicon.svg' );
	echo '<link rel="icon" type="image/svg+xml" href="' . $icon . '">' . "\n";

	// Si existen versiones PNG (necesarias para Safari / iPhone), también se publican.
	$dir = get_template_directory() . '/assets/';
	$uri = get_template_directory_uri() . '/assets/';
	if ( file_exists( $dir . 'favicon-32.png' ) ) {
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $uri . 'favicon-32.png' ) . '">' . "\n";
	}
	if ( file_exists( $dir . 'apple-touch-icon.png' ) ) {
		echo '<link rel="apple-touch-icon" href="' . esc_url( $uri . 'apple-touch-icon.png' ) . '">' . "\n";
	}
}
add_action( 'wp_head', 'pi_favicon_tags', 1 );
add_action( 'admin_head', 'pi_favicon_tags', 1 );
add_action( 'login_head', 'pi_favicon_tags', 1 );

// Desactiva el "Ícono del sitio" de WordPress para que no pise nuestro SVG.
remove_action( 'wp_head', 'wp_site_icon', 99 );

/**
 * Etiquetas extra del <head>: tipografías de Google Fonts, descripción
 * y color de la barra del navegador en celulares.
 */
function pi_head_tags() {
	?>
<meta name="description" content="<?php echo esc_attr( pi_meta_description() ); ?>">
<meta name="theme-color" content="#FFCE02"><!-- Amarillo de marca (Pantone 116 C) -->

<!-- Tipografías: Cinzel (reemplaza a TrajanPro) y Roboto Condensed (reemplaza a Helvetica Neue Condensed) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600&family=Roboto+Condensed:wght@300;400;500&display=swap" rel="stylesheet">
	<?php
}
add_action( 'wp_head', 'pi_head_tags', 2 );

/**
 * Devuelve el código de un ícono SVG guardado en assets/icons/.
 * Se pega "inline" (dentro del HTML) para que tome el color del botón.
 *
 * @param string $name Nombre del archivo sin ".svg" (ej: "whatsapp").
 */
function pi_icon( $name ) {
	$file = get_template_directory() . '/assets/icons/' . sanitize_file_name( $name ) . '.svg';
	return file_exists( $file ) ? file_get_contents( $file ) : '';
}

/**
 * Devuelve el código de la banda amarilla decorativa (assets/banda.svg).
 */
function pi_banda() {
	$file = get_template_directory() . '/assets/banda.svg';
	return file_exists( $file ) ? file_get_contents( $file ) : '';
}
