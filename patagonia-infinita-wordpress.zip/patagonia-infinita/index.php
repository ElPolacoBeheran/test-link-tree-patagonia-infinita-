<?php
/**
 * Patagonia Infinita · index.php
 * ------------------------------------------------------------
 * Plantilla única del tema: dibuja la página de links completa.
 *
 * CÓMO EDITAR LOS LINKS
 * Todo está en la lista $links de más abajo. Cada línea es un botón:
 *   icon    → nombre del ícono (archivo en assets/icons/, sin ".svg")
 *   title   → título del botón (letra amarilla)
 *   sub     → texto chico debajo del título (letra gris)
 *   url     → destino del botón
 *   new_tab → true = abre en pestaña nueva / false = misma pestaña
 *   primary → true = botón destacado con relleno amarillo
 * Para agregar un botón, copiá una línea completa. Para sacar uno, borrala.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$links = array(
	array(
		'icon'    => 'web',
		'title'   => 'Website',
		'sub'     => 'www.patagoniainfinita.com',
		'url'     => 'https://www.patagoniainfinita.com',
		'new_tab' => true,
		'primary' => true,
	),
	array(
		'icon'    => 'whatsapp',
		'title'   => 'WhatsApp',
		'sub'     => 'Send a message',
		'url'     => 'https://wa.me/message/PQUFJX4NZYPMB1',
		'new_tab' => true,
		'primary' => false,
	),
	array(
		'icon'    => 'instagram',
		'title'   => 'Instagram',
		'sub'     => '@patagonia_infinita',
		'url'     => 'https://www.instagram.com/patagonia_infinita/',
		'new_tab' => false, // misma pestaña: evita que Samsung Internet redirija a la Play Store
		'primary' => false,
	),
	array(
		'icon'    => 'facebook',
		'title'   => 'Facebook',
		'sub'     => 'Patagonia Infinita Kayak',
		'url'     => 'https://www.facebook.com/patagoniainfinitakayak',
		'new_tab' => false,
		'primary' => false,
	),
	array(
		'icon'    => 'tripadvisor',
		'title'   => 'TripAdvisor',
		'sub'     => 'tripadvisor.com/patagoniainfinitakayak', // texto que se ve; el botón usa el "url" de abajo
		'url'     => 'https://www.tripadvisor.com/Attraction_Review-g312844-d4039849-Reviews-Patagonia_Infinita-Villa_La_Angostura_Province_of_Neuquen_Patagonia.html',
		'new_tab' => true,
		'primary' => false,
	),
	array(
		'icon'    => 'mail',
		'title'   => 'Email us',
		'sub'     => 'patagoniainfinita@gmail.com',
		'url'     => 'mailto:patagoniainfinita@gmail.com',
		'new_tab' => false,
		'primary' => false,
	),
);
?>
<!DOCTYPE html>
<html lang="en"><!-- Idioma de la página: inglés -->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<!-- Adapta la página al celular; viewport-fit=cover aprovecha pantallas con notch -->
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); /* Acá WordPress inserta el título, el CSS, el favicon y las tipografías (ver functions.php) */ ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- BANDA SUPERIOR: franja amarilla decorativa con curvas de kayak (assets/banda.svg) -->
<div class="banda" aria-hidden="true">
	<?php echo pi_banda(); // phpcs:ignore WordPress.Security.EscapeOutput -- archivo propio del tema ?>
</div>

<main>

	<!-- LOGO: archivo assets/logo.svg. El texto alt lo leen los lectores de pantalla. -->
	<img class="logo" src="<?php echo esc_url( get_template_directory_uri() . '/assets/logo.svg' ); ?>" alt="Patagonia Infinita – Kayak &amp; Adventure, Villa La Angostura" width="318" height="252">

	<!-- LISTA DE LINKS: se genera automáticamente a partir de $links -->
	<ul class="links">
		<?php foreach ( $links as $item ) : ?>
			<?php
			$classes = 'link' . ( $item['primary'] ? ' principal' : '' );
			$target  = $item['new_tab'] ? ' target="_blank" rel="noopener"' : '';
			?>
			<li>
				<a class="<?php echo esc_attr( $classes ); ?>" href="<?php echo esc_url( $item['url'] ); ?>"<?php echo $target; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
					<span class="ico" aria-hidden="true"><?php echo pi_icon( $item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<span class="txt">
						<span class="t"><?php echo esc_html( $item['title'] ); ?></span>
						<span class="s"><?php echo esc_html( $item['sub'] ); ?></span>
					</span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>

	<!-- PIE DE PÁGINA -->
	<footer>KAYAK &amp; ADVENTURE
		<span>Villa La Angostura, Neuquén</span>
		<span>Patagonia Infinita All Rights Reserved Est. 2005</span>
	</footer>

</main>

<?php wp_footer(); ?>
</body>
</html>
