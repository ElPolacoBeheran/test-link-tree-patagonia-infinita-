PATAGONIA INFINITA · Tema de WordPress
=======================================

INSTALACIÓN
1. En WordPress: Apariencia > Temas > Añadir nuevo > Subir tema.
2. Elegí el archivo patagonia-infinita-wordpress.zip, instalá y activá.
3. Listo: la página principal ya muestra la página de links.

ÍCONO DE LA PÁGINA (FAVICON)
- Es el SVG de Patagonia Infinita: assets/favicon.svg
- Para Safari / iPhone hay versiones PNG: assets/favicon-32.png y assets/apple-touch-icon.png
- Se aplica solo en el sitio, el panel de administración y el login.
- El "Ícono del sitio" de Personalizar queda desactivado a propósito, para que no pise este.

EDITAR LINKS Y TEXTOS
- Links: index.php, lista $links (arriba del archivo)
- Título y descripción para Google: functions.php
- Colores y tipografías: style.css, sección 1 (variables)
- Logo: assets/logo.svg  |  Banda amarilla: assets/banda.svg  |  Íconos: assets/icons/

ESTRUCTURA
patagonia-infinita/
  style.css       CSS + cabecera obligatoria del tema
  functions.php   estilos, favicon, tipografías, título
  index.php       la página (lista de links)
  assets/         logo, favicon, banda e íconos
